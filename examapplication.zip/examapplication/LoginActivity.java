package com.example.examapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.SQLException;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText et_uid;
    private EditText et_upwd;
    private CheckBox cb_save;
    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initView();

        pref = getSharedPreferences("login", Context.MODE_PRIVATE);
        editor = pref.edit();
        loadInfo();
    }

    //页面控件初始化
    void initView() {
        //学号输入框
        et_uid = findViewById(R.id.et_uid);
        //密码输入框
        et_upwd = findViewById(R.id.et_upwd);
        //是否保存密码复选框
        cb_save = findViewById(R.id.cb_save);
        findViewById(R.id.btn_login).setOnClickListener(this);  //登录按钮监听
        findViewById(R.id.btn_register).setOnClickListener(this);  //跳转监听



    }

    //保存密码
    void loadInfo(){
        String uid = pref.getString("uid", "");
        String upwd = pref.getString("upwd", "");
        boolean isSave = pref.getBoolean("isSave", false);

        if(isSave){
            et_uid.setText(uid);
            et_upwd.setText(upwd);
            cb_save.setChecked(true);

        }
    }
    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btn_login){
//          1.获得页面用户输入
            String uid = et_uid.getText().toString();
            String upwd = et_upwd.getText().toString();
            boolean isSave = cb_save.isChecked();

//          检测是否已经自动保存账号信息
            if(isSave){
                editor.putString("uid", uid);
                editor.putString("upwd", upwd);
                editor.putBoolean("isSave", isSave);
                editor.commit();
                if(!uid.equals("") && !upwd.equals("")){
                    Toast.makeText(this, "保存成功", Toast.LENGTH_SHORT).show();
                }
            }
            try {
 //             2.数据库初始化
                DBHelper dbHelper = new DBHelper(this, 1);
//              3.调用数据库的方法校验用户
                String sname = dbHelper.verifyStu(uid, upwd);
//              4.判断返回的学生姓名是否为空
                if(!sname.equals("")){
                    //5.登录按钮跳转到主页：在intent中增加数据，实现带数据的跳转
                    Intent i = new Intent(this, MainActivity.class);
                    i.putExtra("sname", sname);
                    i.putExtra("sid", uid);
                    startActivity(i);
                }else {
//              6.学生姓名为空，告诉用户登录失败
                    Toast.makeText(this, "登录失败：用户名或密码错误",
                            Toast.LENGTH_SHORT).show();
                }
            }catch (SQLException e){
                e.printStackTrace();
            }

        }else{  //注册按钮跳转到注册页面
            Intent i = new Intent(this, RegisterActivity.class);
            startActivity(i);
        }

    }
}

