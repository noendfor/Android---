package com.example.examapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText et_rid;
    private EditText et_rname;
    private EditText et_rpwd;
    private EditText et_rdep;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        initView();
    }

    void initView(){
        et_rid = findViewById(R.id.et_rsid);  //学号输入框
        et_rname = findViewById(R.id.et_rname); //学生姓名输入框
        et_rpwd = findViewById(R.id.et_rpwd);  //学生密码输入框
        et_rdep = findViewById(R.id.et_rdep);  //学生学院输入框

        findViewById(R.id.btn_registeruser).setOnClickListener(this);  //注册按钮监听
    }

    @Override
    public void onClick(View v) {
        //1.获得页面用户输入值
        String rid = et_rid.getText().toString();
        String rname = et_rname.getText().toString();
        String rpwd = et_rpwd.getText().toString();
        String rdep = et_rdep.getText().toString();
        Student stu = new Student(rid, rname, rpwd, rdep);

        //2.dbHelper初始化
        DBHelper dbHelper = new DBHelper(this, 1);

        //3.调用数据库的用户注册方法
        if(dbHelper.registerStu(stu) > 0){ //成功插入数据，返回登录页面
            Toast.makeText(this, "注册成功" ,Toast.LENGTH_SHORT).show();
            finish();  //4.将当前的activity结束，返回登录页面
        } else { //5.没有成功往数据库中插入数据，则表示该用户已经被注册
            Toast.makeText(this, "注册失败：该学号已经被注册", Toast.LENGTH_SHORT).show();

        }
    }
}
