package com.example.examapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private String sname;
    private String sid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();
    }

    //1.页面控件初始化
    void initView(){
        TextView tv_welcome = findViewById(R.id.tv_welcome);
        //2.获得从login页面传过来的intent
        if(getIntent() != null){
            Intent i = getIntent();
            //3.从中取出学生姓名，学号信息
            sname = i.getStringExtra("sname");
            sid = i.getStringExtra("sid");
            //4.在页面显示用户名
            tv_welcome.setText("欢迎用户：" + sname);
        }
//      5.对页面四个layout设置监听
        findViewById(R.id.layout_test).setOnClickListener(this);
        findViewById(R.id.layout_review).setOnClickListener(this);
        findViewById(R.id.layout_score).setOnClickListener(this);
        findViewById(R.id.layout_exit).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.layout_test){
//          跳转到考试页面
            Intent i = new Intent(this, TestActivity.class);
            i.putExtra("sname", sname);
            i.putExtra("sid", sid);
            startActivity(i);
        } else if (v.getId() == R.id.layout_review) {
//          跳转到查看考试页面
            Intent i =new Intent(this, ReviewActivity.class);
            i.putExtra("sid", sid);
            startActivity(i);
        } else if (v.getId() == R.id.layout_score) {
//          跳转到查看成绩页面
            Intent i = new Intent(this, ScoreActivity.class);
            i.putExtra("sid", sid);
            startActivity(i);
        } else {
//          返回登录页面
            Intent i =new Intent(this, LoginActivity.class);
            startActivity(i);
        }
    }
}