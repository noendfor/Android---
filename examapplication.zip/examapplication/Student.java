package com.example.examapplication;

public class Student {
    public String sid;
    public String sname;
    public String spwd;
    public String sdep = "";
    public int sscore = 0;
    public int examcnt = 0;
    public String examans;
    public String examtime = "";

    public Student(){

    }

    public Student(String sid, String sname, String spwd, String sdep){
        this.sid = sid;
        this.sname = sname;
        this.spwd = spwd;
        this.sdep = sdep;
    }

    public void setSid(String sid){
        this.sid = sid;
    }

    public void setSname(String sname){
        this.sname = sname;
    }
    public void setSpwd(String spwd){
        this.spwd = spwd;
    }

    public void setSdep(String sdep){
        this.sdep = sdep;
    }
    public void setSscore(int sscore){

    }
    public void setExamans(String examans){

    }
    public void setExamcnt(int examcnt){

    }

    public String getExamans(){
        return examans;
    }
    public int getSscore(){
        return sscore;
    }
    public int getExamcnt(){
        return examcnt;
    }
    public String getSname(){
        return sname;
    }
    public String getSid(){
        return sid;
    }
    public String getSdep(){
        return sdep;
    }
    public String getSpwd(){
        return spwd;
    }

}
