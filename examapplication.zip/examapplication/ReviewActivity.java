package com.example.examapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class ReviewActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tv_question;
    private TextView tv_option1, tv_option2, tv_option3, tv_option4;
    private TextView tv_choose, tv_ans, tv_cnt;
    private Cursor cursor;
    private Button btn_back;
    private String sid;
    private DBHelper dbHelper;
    private Student stu = null;
    private  int idx = 0;
    private String[] stuAns;
    private int cnt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);

        initView();
        initDB();
    }

    //1.初始化页面控件
    void initView(){
        //1.页面控件初始化
        tv_question = findViewById(R.id.tv_question);
        tv_option1 = findViewById(R.id.tv_option1);
        tv_option2 = findViewById(R.id.tv_option2);
        tv_option3 = findViewById(R.id.tv_option3);
        tv_option4 = findViewById(R.id.tv_option4);
        tv_choose = findViewById(R.id.tv_choose);
        tv_cnt = findViewById(R.id.tv_cnt);
        tv_ans = findViewById(R.id.tv_ans);
        btn_back = findViewById(R.id.btn_back);

        findViewById(R.id.btn_pre).setOnClickListener(this);
        findViewById(R.id.btn_next).setOnClickListener(this);
        btn_back.setOnClickListener(this);

        if(getIntent() != null){
            Intent i = getIntent();
            sid = i.getStringExtra("sid");
        }
    }

    //2.数据库初始化
    void initDB(){
        dbHelper = new DBHelper(this, 1);
        stu = dbHelper.queryStu(sid);
        stuAns = stu.getExamans().split(";");
        cursor = dbHelper.loadExam();
        if(cursor != null && cursor.getCount() > 0){
            cnt = cursor.getCount();
            cursor.moveToNext();
            show();
        }
    }

    //3.页面显示题目以及学生作答结果
    void show(){
        tv_cnt.setText(("已完成" + (idx+1) + "/" + cnt));
        tv_question.setText(cursor.getString(1));
        tv_option1.setText("A." + cursor.getString(2));
        tv_option1.setText("B." + cursor.getString(3));
        tv_option1.setText("C." + cursor.getString(4));
        tv_option1.setText("D." + cursor.getString(5));
        tv_choose.setText("你的选择：" + stuAns[idx]);
        tv_ans.setText("正确答案：" + cursor.getString(6));
        //如果学生回答正确，设置学生作答为绿色，否则为红色
        if(stuAns[idx].equals(cursor.getString(6))){
            tv_choose.setTextColor(Color.GREEN);
        } else {
            tv_choose.setTextColor(Color.RED);
        }
        //当到最后一题时，设置返回按钮显示，否则隐藏
        if(idx < (cnt - 1)){
            btn_back.setVisibility(View.GONE);
        } else {
            btn_back.setVisibility(View.VISIBLE);
        }
    }

    //4.设置三个按钮的监听事件
    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btn_pre){
            if(cursor.moveToPrevious()){
                idx--;
                show();
            } else {
                Toast.makeText(this, "已经是第一题", Toast.LENGTH_SHORT).show();
            }
        } else if (v.getId() == R.id.btn_next) {
            if(cursor.moveToNext()){
                idx++;
                show();
            } else {
                Toast.makeText(this, "已经是最后一题", Toast.LENGTH_SHORT).show();
            }
        } else{
            finish();
        }
    }
}