package com.example.examapplication;


import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import  androidx.annotation.Nullable;

import java.io.FileInputStream;

public class DBHelper extends SQLiteOpenHelper{
    //1.定义数据库名称，表格名称
    public static final String DB_NAME = "examination.db";
    public static final int DB_VERSION = 1;
    public static final String TABLE_STU = "student";
    public static final String TABLE_EXAM = "examinfo";

    //2.定义建表语句：创建两个表格
    private static final String CREATE_TABLE_STU = "create table if not exists " +
            TABLE_STU + "(sid text primary key, " +
            "sname text not null, spwd text not null, " +
            "sdep text, sscore integer," +
            "examcnt integer, examtime text, examans text)";
    private  static final String CREATE_TABLE_EXAM = "create table if not exists " +
            TABLE_EXAM + "(tno integer primary key autoincrement, " +
            "question text not null, opt1 text not null," +
            "opt2 text not null, opt3 text not null," +
            "opt4 text not null, righttans text not null)";
    //3.修改构造函数
    public DBHelper(@Nullable Context context, int version) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    //4.创建表格
    @Override
    public void onCreate(SQLiteDatabase db) {
        try{
            db.execSQL(CREATE_TABLE_STU);
            db.execSQL(CREATE_TABLE_EXAM);
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public long registerStu(Student stu){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues vals = new ContentValues();
        vals.put("sid", stu.getSid());
        vals.put("sname", stu.getSname());
        vals.put("spwd", stu.getSpwd());
        vals.put("sdep", stu.getSdep());
        long res = db.insert(TABLE_STU, null, vals);
        return res;
    }


    @SuppressLint("Range")
    public String verifyStu(String sid, String spwd){
        SQLiteDatabase db = getReadableDatabase();
        String whereClause = "sid=? and spwd=?";

        //1.根据学号以及密码进行查询
        Cursor cursor = db.query(TABLE_STU,
                null, whereClause,
                new String[] {sid, spwd}, null, null, null);

        //2.查询到数据：返回学生名字
        if(cursor.getCount() > 0){
            cursor.moveToNext();
            return cursor.getString(cursor.getColumnIndex("sname"));
        }
        //3.否则，返回空字符串
        return "";
    }

    //查询所有题目
    public Cursor loadExam(){
        Cursor cursor = null;
        SQLiteDatabase db = getReadableDatabase();
        cursor = db.query(TABLE_EXAM,
                null, null, null,
                null, null, null);
        return cursor;
    }

    //更新数据库中学生成绩
    public int updateGrade(Student stu){
        SQLiteDatabase db = getWritableDatabase();
        String whereClause = "sid=?";
        String [] args = new String[]{stu.getSid()};
        ContentValues vals = new ContentValues();
        vals.put("sscore", stu.sscore);
        vals.put("examans", stu.examans);
        vals.put("examcnt", stu.examcnt);
        return db.update(TABLE_STU, vals, whereClause, args);
    }

    //通过学号查询学生成绩信息等

    @SuppressLint("Range")
    public Student queryStu(String sid){
        SQLiteDatabase db = getReadableDatabase();
        String whereCaluse = "sid=?";  //根据学号查询学生信息，并将数据放入student对象
        String [] args = new String[]{sid};
        Student stu = null;
        Cursor cursor = db.query(TABLE_STU,
                null, whereCaluse, new String[] {sid},
                null, null, null);
        if(cursor.getCount() > 0){
            stu = new Student();
            cursor.moveToNext();
            stu.setSid(sid);
            stu.setSname(cursor.getString(cursor.getColumnIndex("sname")));
            stu.setSdep(cursor.getString(cursor.getColumnIndex("sdep")));
            stu.setSscore(cursor.getInt(cursor.getColumnIndex("sscore")));
            stu.setExamcnt(cursor.getInt(cursor.getColumnIndex("examcnt")));
            stu.setExamans(cursor.getString(cursor.getColumnIndex("examans")));
        }
        return stu;
    }
}

