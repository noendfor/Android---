package com.example.examapplication;


import  androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class TestActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tv_sname;
    private TextView tv_cnt;
    private TextView tv_question;
    private TextView tv_option1;
    private TextView tv_option2;
    private TextView tv_option3;
    private TextView tv_option4;
    private TextView tv_choose;
    private DBHelper dbHelper;
    private Cursor cursor;  //查询得到所有题目
    private int questionCnt;  //题目总数
    private String[] stuAns;  //学生的答案，用数组保存
    private String[] rightAns;  //正确答案
    private int idx = 0;  //当前题目索引号
    Student candicate = null;  //6.设置该对象为全局变量

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        initView();
        //获得从Main页面传过来的intent
        if(getIntent() != null) {
            Intent i = getIntent();
            tv_sname.setText("用户：" + i.getStringExtra("sname"));
            //5.创建student对象表示当前考生:candicate,并设置该对象的学号
            candicate = new Student();
            candicate.setSid(i.getStringExtra("sid"));
        }
        initDB();

    }

    void initView(){
        //1.页面控件初始化
        tv_sname = findViewById(R.id.tv_sname);
        tv_cnt = findViewById(R.id.tv_cnt);
        tv_question = findViewById(R.id.tv_question);
        tv_option1 = findViewById(R.id.tv_option1);
        tv_option2 = findViewById(R.id.tv_option2);
        tv_option3 = findViewById(R.id.tv_option3);
        tv_option4 = findViewById(R.id.tv_option4);
        tv_choose = findViewById(R.id.tv_choose);

        //2.对每个选项的TextView设置监听
        tv_option1.setOnClickListener(this);
        tv_option2.setOnClickListener(this);
        tv_option3.setOnClickListener(this);
        tv_option4.setOnClickListener(this);

        //3.对三个按钮设置监听
        findViewById(R.id.btn_pre).setOnClickListener(this);
        findViewById(R.id.btn_next).setOnClickListener(this);
        findViewById(R.id.btn_submit).setOnClickListener(this);
    }

    //1.数据库初始化
    void initDB(){
        dbHelper = new DBHelper(this, 1);
        cursor = dbHelper.loadExam();
        if(cursor != null && cursor.getCount() > 0) {
            questionCnt = cursor.getCount();
            stuAns = new String[questionCnt];  //创建空的数组用于存放学生答案
            rightAns = new String[questionCnt];  //创建空的数组用于存放题目的正确答案

            cursor.moveToNext();
            rightAns[idx] = cursor.getString(6);  //设置正确答案数组的第一个值
            show();
        }
    }

    void show(){
        //3.页面显示题目，做题进度与用户选择的答案
        tv_cnt.setText("已完成：" + (idx + 1) + "/" + questionCnt);
        tv_question.setText(cursor.getString(1));
        tv_option1.setText("A." + cursor.getString(2));
        tv_option2.setText("B." + cursor.getString(3));
        tv_option3.setText("C." + cursor.getString(4));
        tv_option4.setText("D." + cursor.getString(5));

        if(stuAns[idx] != null){
            tv_choose.setText("你的选择：" + stuAns[idx]);
        } else {
          tv_choose.setText("");
        }
    }

    @Override
    public void onClick(View v) {
        if(cursor == null || cursor.getCount() < 0){
            return;
        }
        //1.跳回上一题
        if(v.getId() == R.id.btn_pre) {
            if (cursor.moveToPrevious()) {
                idx--; //题号-1
                show();
            } else {
                Toast.makeText(this, "已经是第一题", Toast.LENGTH_SHORT).show();
            }
        }//2.跳转到下一题
       else if(v.getId() == R.id.btn_next){
                if(cursor.moveToNext()){
                    idx++;  //题号+1
                    if(rightAns[idx] == null){  // 记录该题的正确答案
                        rightAns[idx] = cursor.getString(6);
                    }
                    show();
                } else {
                    Toast.makeText(this, "已经是最后一题", Toast.LENGTH_SHORT).show();
                }
        } //3.用户点击选项选择
        else if (v.getId() == R.id.tv_option1 || v.getId() == R.id.tv_option2
                || v.getId() == R.id.tv_option3 || v.getId() == R.id.tv_option4) {
            TextView tv = (TextView) v;  //将当前v对象强转为TextView对象
            stuAns[idx] = tv.getText().toString().substring(2); //记录学生的答案
            tv_choose.setText("你的选择：" + tv.getText().toString()); //显示学生的选择
        }
        else {
            //4.用户点击交卷
            calScore();  //计算学生成绩
            dbHelper.updateGrade(candicate);  //更新数据库student表中学生的成绩
            Toast.makeText(this, "提交成功", Toast.LENGTH_SHORT).show();
            finish(); //结束当前activity，返回主页
        }
    }

    //7.计算学生成绩
    void calScore(){
        int score = 0;
        for(int i = 0; i < questionCnt; i++){
            if(stuAns[i] == null){  //学生没作答，直接跳到下一题
                stuAns[i] = "None";
                continue;
            }
            if(stuAns[i].equals(rightAns[i])){  //判断学生答案和正确答案是否一致
                score = score + 10;
            }
        }
        candicate.setSscore(score);  //设置当前考生成绩
        String ans = String.join(";", stuAns);
        candicate.setExamans(ans);  //设置当前考生的答案
        int examcnt = candicate.getExamcnt() + 1;
        candicate.setExamcnt(examcnt);  //设置当前考生的考试次数
    }
}
