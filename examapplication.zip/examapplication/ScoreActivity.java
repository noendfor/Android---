package com.example.examapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


public class ScoreActivity extends AppCompatActivity implements View.OnClickListener {

    //4
    private TextView tv_sid;
    private TextView tv_sname;
    private TextView tv_sdep;
    private TextView tv_sscore;
    private TextView tv_ecnt;
    private ImageView iv_res;
    private String sid;
    private DBHelper dbHelper;
    private Student stu = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sore);

        initView();
        initDB();
        show();
    }

    //1.页面初始化
    void initView(){
        tv_sid = findViewById(R.id.tv_sid);
        tv_sname = findViewById(R.id.tv_sname);
        tv_sdep = findViewById(R.id.tv_sdep);
        tv_sscore = findViewById(R.id.tv_sscore);
        tv_ecnt = findViewById(R.id.tv_ecnt);
        iv_res = findViewById(R.id.iv_res);
        findViewById(R.id.btn_back).setOnClickListener(this);
        if(getIntent() != null){
            Intent i = getIntent();
            sid = i.getStringExtra("sid");
        }
    }

    //2.数据库初始化并根据学号查询该学生数据
    void initDB(){
        dbHelper = new DBHelper(this, 1);
        stu = dbHelper.queryStu(sid);
    }

    //3.显示学生信息
    void show(){
        if(stu != null){
            tv_sid.setText(stu.getSid());
            tv_sname.setText(stu.getSname());
            tv_sdep.setText(stu.getSdep());
            tv_sscore.setText(String.valueOf(stu.getSscore()));
            tv_ecnt.setText(String.valueOf(stu.getExamcnt()));
            //判断是否及格
            if(stu.getSscore() >= 60){
                iv_res.setImageResource(R.drawable.pass);
            } else {
                iv_res.setImageResource(R.drawable.failed);
            }
        }
    }

    //6.结束当前页面
    @Override
    public void onClick(View v) {
        finish();
    }
}